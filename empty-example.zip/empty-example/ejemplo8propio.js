let cnv;
let detailX;
let detailY;
function setup() {
  createCanvas(400, 400, WEBGL);
  detailX = createSlider(3, 24, 3);
  detailX.position(10, height + 5);
  detailX.style('width', '80px');
  detailY = createSlider(3, 16, 3);
  detailY.position(10, height + 25);
  detailY.style('width', '80px');
}

function draw() {
	fill(50,150,100);
  background(205, 105, 94);
  rotateY(millis() / 1000);
  sphere(80, detailX.value(), detailY.value());

}
