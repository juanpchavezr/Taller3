let cnv;
let detailX1;
let detailY1;
let detailZ1;
let detailX2;
let detailY2;
let detailZ2;
let detailX3;
let detailY3;
let detailZ3;
let detailX4;
let detailY4;
let detailZ4;
let detailX5;
let detailY5;
let detailZ5;

function setup() {
  createCanvas(710, 400, WEBGL);
  detailX1 = createSlider(3, 24, 3);
  detailX1.position(10, height + 5);
  detailX1.style('width', '80px');
  detailY1 = createSlider(3, 16, 3);
  detailY1.position(10, height + 25);
  detailY1.style('width', '80px');
  detailZ1 = createSlider(3, 16, 3);
  detailZ1.position(10, height + 45);
  detailZ1.style('width', '80px');
  //
  detailX2 = createSlider(3, 24, 3);
  detailX2.position(100, height + 5);
  detailX2.style('width', '80px');
  detailY2 = createSlider(3, 16, 3);
  detailY2.position(100, height + 25);
  detailY2.style('width', '80px');
  detailZ2 = createSlider(3, 16, 3);
  detailZ2.position(100, height + 45);
  detailZ2.style('width', '80px');
    //
  detailX3 = createSlider(3, 24, 3);
  detailX3.position(200, height + 5);
  detailX3.style('width', '80px');
  detailY3 = createSlider(3, 16, 3);
  detailY3.position(200, height + 25);
  detailY3.style('width', '80px');
  detailZ3 = createSlider(3, 16, 3);
  detailZ3.position(200, height + 45);
  detailZ3.style('width', '80px');
      //
  detailX4 = createSlider(5, 24, 3);
  detailX4.position(300, height + 5);
  detailX4.style('width', '80px');
  detailY4 = createSlider(3, 16, 3);
  detailY4.position(300, height + 25);
  detailY4.style('width', '80px');
  detailZ4 = createSlider(3, 16, 3);
  detailZ4.position(300, height + 45);
  detailZ4.style('width', '80px');
  }

function draw() {
	background(205, 105, 94);
  translate(-240, -100, 0);
  push();
  fill(50,150,100);
  rotateY(millis() / 1000);
  rotateX(millis() / 6000);
  sphere(detailZ1.value(), detailX1.value(), detailY1.value());
  pop();
  //
  translate(0, 100, 10);
  push();
  fill(10,10,126);
  rotateY(millis() / 8000);
  rotateX(millis() / 4000);
  torus(detailZ2.value(), detailZ2.value(), detailX2.value(),detailY2.value());
  pop();
  //
  translate(240, 0, 10);
  fill(30,1800,200);
  rotateY(millis() / 2000);
  rotateX(millis() / 1500);
  cone(detailZ3.value(), detailZ3.value(), detailX3.value(),detailY3.value());
  pop();
  //
  translate(-240 , 20, 10);
  push();
  fill(200,100,10);
  rotateY(millis() / 5000);
  rotateX(millis() / 2000);
  cylinder(detailZ4.value(), detailZ4.value(), detailX4.value(), detailY4.value());
  pop();
}