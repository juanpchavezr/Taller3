let cnv;
let detailX;
let detailY;
function setup() {
  createCanvas(400, 400, WEBGL);
  detailX = createSlider(3, 24, 3);
  detailX.position(10, height + 5);
  detailX.style('width', '80px');
  detailY = createSlider(3, 16, 3);
  detailY.position(10, height + 5);
  detailY.style('width', '80px');
}

function draw() {
  background(200);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  box(50);
  background(205, 105, 94);
  rotateY(millis() / 1000);
  sphere(40, detailX.value(), detailY.value());
}
