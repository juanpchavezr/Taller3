

//crea una tabla que guarda los datos del archivo .csv
let table; 

//se crea un arreglo
let bubbles = []; 
let maxDato=0;
//numero de filas en el archivo
let rowCount;
let tiempo = []; 

//tercero
//creo arreglos, que guardan los valores de cada columna
let comcel = [];
let datoComcel = 0;


//cuarto
let datoMovistar = 0;

//quinto

let  tigo =[];
let  datoTigo = 0;
let  uff=[];
let datoUff = 0;
// Put any asynchronous data loading in preload to complete before "setup" is run
function preload() 
{
  //carga el archivo y tiene en cuenta el titulo de las columnas
  table = loadTable("assets/datosInternetCompleto1.csv", "header");
}


function setup() 
{
  createCanvas(640, 360);
  
  //numero de filas en el archivo
  rowCount = table.getRowCount();

  //creamos un objeto que guarda la información de las filas de la tabla
  const row = table.getRows();  

  for (let i = 0; i < rowCount; i++) 
  {
    //guardamos la información de la fila "x" en una constante
    const tiempo = row[i].getString("Tiempo");
    //guardamos la información de la fila "y" en una constante
    const Comcel = row[i].getInt("ComcelProveedorSuscripciom");
    //guardamos la información de la fila "diameter" en una constante
    const movistar= row[i].getInt("MovistarProveedorSuscripcion");
    //guardamos la información de la fila "name" en una constante
    const  tigo= row[i].getInt("TigoProveedorSuscripcion");

    //Adiciono al arreglo un objeto de tipo Bubble, donde inicializo el objeto creando la Burbuja
   // bubbles.push(new Bubble(x, y, diameter, name));
    //se crean la cantidad de burbujas acorde a la cantidad de datos
      datoComcel = comcel[i];
    if (datoComcel > maxDato) 
    {
      maxDato = datoComcel;
    }
  }

}


function draw() 
{
  background(255);
  fill(100);
  rect(0, 70, 560, 242);
   fill(255);
  rect(55, 80, 420, 220);
    
  strokeWeight(1);
  stroke(0);
  
  //se recorre la cantidad de burbujas, que es lo mismo que recorrer la cantidad de datos
  //for (let i = 0; i < bubbles.length; i++)
  for (let i = 0; i < rowCount; i++) 
  {
      let x = map(i, 0, rowCount-1, 55, 475); //desde la 0 hasta la 13
      line(x, 80, x, 300);
      
      //segundo
      //se coloca el texto en cada linea
      fill(0);
  	//recorre cada burbuja y llama a la función dibujar para mostrarla
   // bubbles[i].dibujar();
    //recorre cada burbuja y llama a la función mouseOver para mostrar  la información
    //bubbles[i].mouseOver(mouseX, mouseY);
  } 
}
for (let i = 0; i < maxDato; i+=2000000) 
  {
      //se replican las lineas, en las pocisiones dentro del espacio del diagrama
      let y = map(i, 0, maxDato, 300, 80);
      line(55, y, 475, y);
      
      //texto con el valor de cada linea
      fill(255);
      //se coloca el texto en cada linea
      text(i, 0, y);
  }  
    
  //tercero A
  
  //scatter de comcel
  
  //fill(10,7,240);
  
  
  //tercero B
  
  // puntos comcel
  //recorre 14 veces
  for (let i = 0; i < rowCount; i++)  //desde la 0 hasta la 13
  {
      let x = map(i, 0, rowCount-1, 55, 475); //desde la 0 hasta la 13
      let y = map(comcel[i], 0, maxDato, 300, 100);
      ellipse(x, y,10,10);
      rect(x, y,10,300-y); //alto - el punto y
      //println(i + "  " + comcel[i]  + "  " + x  + "  " + y);
  }
  
  
  //tercero C
  /*
  //poligono comcel
  beginShape();
  for (int i = 0; i < rowCount; i++)  //desde la 0 hasta la 13
  {
      float x = map(i, 0, rowCount-1, 55, 475); //desde la 0 hasta la 13
      float y = map(comcel[i], 0, maxDato, 300, 100); 
      vertex(x, y); 
  }
  vertex(475, 300);
  vertex(55, 300);
  endShape(CLOSE);
  */
  
  //cuarto A
  
  // puntos MOVISTAR
 
  //fill(7,229,30);
  //recorre 14 veces
  for (let i = 0; i < rowCount; i++) //desde la 0 hasta la 13
  {
      let x = map(i, 0, rowCount-1, 55, 475); //desde la 0 hasta la 13
      let y = map(movistar[i], 0, maxDato, 300, 100);
      ellipse(x, y, 10,10);
      rect(x, y,10,300-y); //alto - el punto y
      //println(i + "  " + movistar[i]  + "  " + x  + "  " + y);
  } 
   
  
  //cuarto B
  
  //poligono MOVISTAR
 /* beginShape();
  for (int i = 0; i < rowCount; i++) //desde la 0 hasta la 13
  {
      float x = map(i , 0, rowCount-1, 55, 475);  //desde la 0 hasta la 13
      float y = map(movistar[i], 0, maxDato, 300, 100);
      vertex(x, y); 
  }
  vertex(475, 300);
  vertex(55, 300);
  endShape(CLOSE);
  */
  
  //quinto A
  
  // puntos TIGO
  
  //fill(255,25,219,170);
  //recorre 14 veces
  for (let i = 0; i < rowCount; i++) //desde la 0 hasta la 13
  {
      let x = map(i, 0, rowCount-1, 55, 475); //desde la 0 hasta la 13
      let y = map(tigo[i], 0, maxDato, 300, 100);
      ellipse(x, y, 10,10);
      //println(i + "  " + tigo[i]  + "  " + x  + "  " + y);
  }    
  
  //poligono Tigo
  beginShape();
  for (let i = 0; i < rowCount; i++) //desde la 0 hasta la 13
  {
      let x = map(i, 0, rowCount-1, 55, 475);   //desde la 0 hasta la 13
      let y = map(tigo[i], 0, maxDato, 300, 100);
      vertex(x, y); 
  }
  vertex(475, 300);
  vertex(55, 300);
  endShape(CLOSE);
  
  
  //quinto B
  
  //puntos Uff
  
  
  //recorre 14 veces
  for (let i = 0; i < rowCount; i++) //desde la 0 hasta la 13
  {
      let x = map(i, 0, rowCount-1, 55, 475); //desde la 0 hasta la 13
      let y = map(uff[i], 0, maxDato, 300, 100);
      ellipse(x,y,10,10); 
      fill(226,234,7);
      //println(i + "  " + Uff[i]  + "  " + x  + "  " + y);
  }
    
  //poligono Uff
  beginShape();
  for (let i = 0; i < rowCount; i++) 
  {
      let x = map(i, 0, rowCount-1, 55, 475);
      let y = map(uff[i], 0, maxDato, 300, 100);
      vertex(x, y); 
  }
  vertex(475, 300);
  vertex(55, 300);
  endShape(CLOSE); 


// clase Bubble 
class Bubble 
{
  //se determinan los variables del objeto
  constructor(x, y, diameter, name) 
  {
    this.x = x;
    this.y = y;
    this.diameter = diameter;
    this.name = name;

    this.over = false;
  }

  //se crea la función donde se determina si el mouse esta encima de la burbuja, le entra como para metro mouseX y mouseY
  mouseOver(px, py) 
  {
  	//distancia que hay entre la posición del mouse y la burbuja
    let distancia = dist(px, py, this.x, this.y);

    //si la distancia entre el mouse y la burbuja es cercana
    if(distancia < 20)
    {
    	// entonces la variable over pongala en true
    	this.over = true;	
    }
    //si la distancia entre el mouse y la burbuja es lejana
    else
    {   
    	// entonces la variable over pongala en false
    	this.over = false;
    }
  }

  //muestra la burbuja
  dibujar() 
  {
    stroke(0);
    strokeWeight(0.8);
    noFill();
    //dibuja la burbuja segun los datos obtenidos del archivo en el setup
    ellipse(this.x, this.y, this.diameter, this.diameter);

    //si la variable over es igual a true, es decir, si esta cerca a la burbuja  
    if (this.over == true) 
    {
      fill(0);
      textAlign(CENTER);
      //coloca el texto del dato mas abajo de la burbuja
      text(this.name, this.x, this.y + 40);
    }
  }
}
