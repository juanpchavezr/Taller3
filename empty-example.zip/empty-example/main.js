let rectangulo1;
let rectangulo2;
let rectangulo3;


function setup() 
{
  createCanvas(400, 400);

  //creamos los rectangulos inicializando la clase
  rectangulo1 = new Rectangle('primero', 10, 10, 20, 20);
  rectangulo2 = new Rectangle('segundo', 50, 100, 200, 120);
  rectangulo3 = new Rectangle('tercero', 150, 250, 60, 180);
}
function draw() 
{
  background(150);

  rectangulo1.mostrar();
  rectangulo2.mostrar();
  rectangulo3.mostrar();
}